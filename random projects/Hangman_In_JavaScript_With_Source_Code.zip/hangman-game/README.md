# Hangman Game

Find the word by selecting a letter each time. You win if you find the word in certain amount of chances.

# Project Specifications

- Build hangman image with SVG
- Pick a random word
- Show correct letters in the word
- Show incorrect letters
- Indicate if same letter is entered more than once
- Show a modal when won or lost
